import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.*; 
import java.io.*; 
import java.util.*; 
import java.io.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Tetris extends PApplet {





Board TetrisBoard;
Random r;
int s = 2;
int m;
int lastMillis, diff = 0;
boolean gameOver;

PFont font;
PImage background;
PImage logo;
PImage controls;

public void showNext() {
  pushMatrix();
  translate(365, 100);
  fill(0, 0, 0);
  textSize(20);
  textAlign(CENTER);
  text("NEXT", 30, -5);
  int start = TetrisBoard.nextPiece;
  for (int i = start, counter = 0; i < start + 4; i++, counter++) {
    pushMatrix();
    translate(0, counter*60);
    fill(40, 40, 40);
    rect(0, 0, 60, 60);
    if (TetrisBoard.nextPieces.get(i%14) == 1) {
      fill(240, 240, 0);
      rect(15, 15, 15, 15);
      rect(15, 30, 15, 15);
      rect(30, 15, 15, 15);
      rect(30, 30, 15, 15);
    } else if (TetrisBoard.nextPieces.get(i%14) == 2) {
      fill(0, 240, 240);
      rect(24, 6, 12, 12);
      rect(24, 18, 12, 12);
      rect(24, 30, 12, 12);
      rect(24, 42, 12, 12);
    } else if (TetrisBoard.nextPieces.get(i%14) == 3) {
      fill(240, 160, 0);
      rect(15, 7.5f, 15, 15);
      rect(15, 22.5f, 15, 15);
      rect(15, 37.5f, 15, 15);
      rect(30, 37.5f, 15, 15);
    } else if (TetrisBoard.nextPieces.get(i%14) == 4) {
      fill(0, 0, 240);
      rect(30, 7.5f, 15, 15);
      rect(30, 22.5f, 15, 15);
      rect(30, 37.5f, 15, 15);
      rect(15, 37.5f, 15, 15);
    } else if (TetrisBoard.nextPieces.get(i%14) == 5) {
      fill(0, 240, 0);
      rect(22.5f, 15, 15, 15);
      rect(37.5f, 15, 15, 15);
      rect(7.5f, 30, 15, 15);
      rect(22.5f, 30, 15, 15);
    } else if (TetrisBoard.nextPieces.get(i%14) == 6) {
      fill(240, 0, 0);
      rect(7.5f, 15, 15, 15);
      rect(22.5f, 15, 15, 15);
      rect(22.5f, 30, 15, 15);
      rect(37.5f, 30, 15, 15);
    } else {
      fill(160, 0, 240);
      rect(22.5f, 15, 15, 15);
      rect(7.5f, 30, 15, 15);
      rect(22.5f, 30, 15, 15);
      rect(37.5f, 30, 15, 15);
    }
    popMatrix();
  }

  popMatrix();
}

public void showSaved() {
  pushMatrix();
  translate(55, 100);
  fill(0, 0, 0);
  textSize(20);
  textAlign(CENTER);
  text("HOLD", 30, -5);
  fill(40, 40, 40);
  rect(0, 0, 60, 60);
  if (TetrisBoard.savedPiece == null) {
  } else if (TetrisBoard.savedPiece.col == 1) {
    fill(240, 240, 0);
    rect(15, 15, 15, 15);
    rect(15, 30, 15, 15);
    rect(30, 15, 15, 15);
    rect(30, 30, 15, 15);
  } else if (TetrisBoard.savedPiece.col == 2) {
    fill(0, 240, 240);
    rect(24, 6, 12, 12);
    rect(24, 18, 12, 12);
    rect(24, 30, 12, 12);
    rect(24, 42, 12, 12);
  } else if (TetrisBoard.savedPiece.col == 3) {
    fill(240, 160, 0);
    rect(15, 7.5f, 15, 15);
    rect(15, 22.5f, 15, 15);
    rect(15, 37.5f, 15, 15);
    rect(30, 37.5f, 15, 15);
  } else if (TetrisBoard.savedPiece.col== 4) {
    fill(0, 0, 240);
    rect(30, 7.5f, 15, 15);
    rect(30, 22.5f, 15, 15);
    rect(30, 37.5f, 15, 15);
    rect(15, 37.5f, 15, 15);
  } else if (TetrisBoard.savedPiece.col == 5) {
    fill(0, 240, 0);
    rect(22.5f, 15, 15, 15);
    rect(37.5f, 15, 15, 15);
    rect(7.5f, 30, 15, 15);
    rect(22.5f, 30, 15, 15);
  } else if (TetrisBoard.savedPiece.col == 6) {
    fill(240, 0, 0);
    rect(7.5f, 15, 15, 15);
    rect(22.5f, 15, 15, 15);
    rect(22.5f, 30, 15, 15);
    rect(37.5f, 30, 15, 15);
  } else {
    fill(160, 0, 240);
    rect(22.5f, 15, 15, 15);
    rect(7.5f, 30, 15, 15);
    rect(22.5f, 30, 15, 15);
    rect(37.5f, 30, 15, 15);
  }
  popMatrix();
}

public void showExtra() {
  fill(230, 30, 30);
  textSize(25);
  textAlign(RIGHT);
  text("SCORE", 670, 265);
  text("LINES CLEARED", 670, 305);
  text("LEVEL", 670, 345);
  textAlign(LEFT);
  text(TetrisBoard.score, 685, 265);
  text(TetrisBoard.lines, 685, 305);
  text(TetrisBoard.level, 685, 345);
  fill(0, 0, 0);
  textSize(25);
  textAlign(LEFT);
  text("Rotate", 515, 410);
  text("Left", 515, 410+43*1);
  text("Right", 515, 410+43*2);
  text("Down", 515, 410+43*3);
  text("Pause", 690, 410);
  text("Restart", 690, 410+43*1);
  text("Hold", 742, 410+43*2);
  text("Drop", 765, 410+43*3);
}

public void setup() {
  
  TetrisBoard = new Board();
  r = new Random();
  gameOver = false;
  font = loadFont("yeet.vlw");
  textFont(font);
  background = loadImage("background.png");
  logo = loadImage("logo.png");
  logo.resize(0, 160);
  controls = loadImage("controls.png");
}

public void draw() {
  int m = (millis()-diff);
  background(255);
  image(background, 0, 0);
  image(logo, 550, 50);
  image(controls, 460, 375);
  showExtra();
  TetrisBoard.display(m, s);
  if (m >= s) {
    s+=TetrisBoard.speed*1000;
  }
  showNext();
  showSaved();
  for (int i = 0; i < TetrisBoard.grid[0].length; i++) {
    if (TetrisBoard.grid[0][i]!= 0) endGame();
  }
}

public void endGame() {
  noLoop();
  gameOver = true;
  lastMillis = millis();
  fill(110, 110, 110, 230);
  rect(-1, -1, width+1, height+1);
  fill(255, 255, 255);
  textSize(100);
  textAlign(CENTER);
  text("GAME OVER", width/2, height/2-75);
  textSize(30);
  text("Press 'r' to restart", width/2, height/2-40);
  textAlign(RIGHT);
  text("SCORE", width/2-10, height/2+50);
  text("LINES CLEARED", width/2-10, height/2+100);
  text("LEVEL", width/2-10, height/2+150);
  textAlign(LEFT);
  text(TetrisBoard.score, width/2+10, height/2+50);
  text(TetrisBoard.lines, width/2+10, height/2+100);
  text(TetrisBoard.level, width/2+10, height/2+150);
}

public void keyPressed() {
  if (looping) {
    TetrisBoard.keyPressed();
    TetrisBoard.currentPiece.keyPressed();
  }
  if (key == 'r') {
    if(gameOver){
      gameOver = false;
      diff+=millis()-lastMillis;
    }
    setup();
    loop();
  }
  if (key == 'p') {
    if (looping) {
      noLoop();
      lastMillis = millis();
      fill(110, 110, 110, 230);
      rect(-1, -1, width+1, height+1);
      fill(255, 255, 255);
      textSize(100);
      textAlign(CENTER);
      text("PAUSED", width/2, height/2);
      textSize(40);
      text("Press 'p' to unpause", width/2, height/2+50);
    } else {
      diff += millis() - lastMillis;
      loop();
    }
  }
}



class Board {
  int[][] grid;
  int gridh, gridw;
  int score, lines, level;
  double speed;
  Piece currentPiece, savedPiece, ghostPiece;
  List<Integer> nextPieces;
  int nextPiece;
  boolean hasSaved;

  Board() {
    grid = new int[27][10];
    gridh = 25;
    gridw = 10;
    score = 0;
    lines = 0;
    score = 0;
    level = 1;
    speed = .8f;
    nextPieces = Arrays.asList(new Integer[]{1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7});
    nextPiece = 1;
    Collections.shuffle(nextPieces.subList(0, 7)); //randomizes the next pieces
    currentPiece = newPiece(nextPieces.get(0)); //set up the current piece and the ghost piece
    currentPiece.moveDown();
    currentPiece.moveDown();
    ghostPiece = newPiece(currentPiece.col);
    ghostPiece.col*=10;
    hasSaved = false;
    for (int i = 0; i < grid[26].length; i++) {
      grid[26][i] = -1;
    }
  }


  public void showBoard() {
    fill(255, 255, 255);
    rect(0, 40, 200, 480);
    for (int x = 2; x < gridh+1; x++) {
      for (int y = 0; y < grid[x].length; y++) {
        if (grid[x][y] == 1) {
          fill(240, 240, 0);
        } else if (grid[x][y] == 2) {
          fill(0, 240, 240);
        } else if (grid[x][y] == 3) {
          fill(240, 160, 0);
        } else if (grid[x][y] == 4) {
          fill(0, 0, 240);
        } else if (grid[x][y] == 5) {
          fill(0, 240, 0);
        } else if (grid[x][y] == 6) {
          fill(240, 0, 0);
        } else if (grid[x][y] == 7) {
          fill(160, 0, 240);
        } else if (grid[x][y] == 10) {
          fill(240, 240, 0, 85);
        } else if (grid[x][y] == 20) {
          fill(0, 240, 240, 85);
        } else if (grid[x][y] == 30) {
          fill(240, 160, 0, 85);
        } else if (grid[x][y] == 40) {
          fill(0, 0, 240, 85);
        } else if (grid[x][y] == 50) {
          fill(0, 240, 0, 85);
        } else if (grid[x][y] == 60) {
          fill(240, 0, 0, 85);
        } else if (grid[x][y] == 70) {
          fill(160, 0, 240, 85);
        } else {
          fill(40, 40, 40);
        }
        rect(y*20, x*20, 20, 20);
      }
    }
  }

  public void show2D(int[][] arr) {
    System.out.println("\n");
    for (int x = 0; x < arr.length; x++) {
      System.out.println("\n");
      for (int y = 0; y < arr[x].length; y++) {
        System.out.print(arr[x][y] + " ");
      }
    }
    System.out.println("\n");
  }

  public void clearLine() {
    int count = 0;
    for (int r = 0; r < grid.length-1; r++) {
      boolean space = true;
      for (int c = 0; c < grid[r].length && space; c++) {
        if (grid[r][c] == 0 || grid[r][c] == ghostPiece.col) space = false;
      }
      if (space) {
        clearLine(r);
        if (lines%10 == 0) {
          level++;
          if (level == 2) speed = .72f;
          else if (level == 3) speed = .63f;
          else if (level == 4) speed = .55f;
          else if (level == 5) speed = .47f;
          else if (level == 6) speed = .38f;
          else if (level == 7) speed = .3f;
          else if (level == 8) speed = .22f;
          else if (level == 9) speed = .13f;
          else if (level == 10) speed = .1f;
          else if (level == 11) speed = .08f;
          else if (level == 14) speed = .07f;
          else if (level == 17) speed = .05f;
          else if (level == 20) speed = .03f;
          else if (level == 30) speed = .02f;
        }
        count++;
      }
    }
    if (count == 1) score += 40*level;
    else if (count == 2) score += 100*level;
    else if (count == 3) score += 300*level;
    else if (count == 4) score += 1200*level;
  }

  public void clearLine(int row) {
    for (int i = row; i > 0; i--) {
      grid[i] = grid[i-1];
    }
    grid[0] = new int[gridw];
    lines++;
  }

  public void playPiece() {
    if (currentPiece.isColliding()) {
      currentPiece = newPiece(nextPieces.get(nextPiece));
      currentPiece.moveDown();
      currentPiece.moveDown();
      ghostPiece = newPiece(currentPiece.col);
      ghostPiece.col*=10;
      nextPiece = (nextPiece + 1) % 14;
      int end = (nextPiece + 3) % 14;
      if (end == 0 || end == 7) Collections.shuffle(nextPieces.subList(end, end+7));
      hasSaved = false;
      //System.out.println(Arrays.toString(nextPieces.toArray()));
    } else {
      currentPiece.moveDown();
    }
  }

  public Piece newPiece(int s) {
    if (s == 1) {
      return new OPiece(0, 4, this);
    } else if (s == 2) {
      return new IPiece(1, 5, this);
    } else if (s == 3) {
      return new LPiece(1, 4, this);
    } else if (s == 4) {
      return new JPiece(1, 4, this);
    } else if (s == 5) {
      return new SPiece(1, 4, this);
    } else if (s == 6) {
      return new ZPiece(1, 4, this);
    } else {
      return new TPiece(1, 4, this);
    }
  }

  public void endGame() {
  }

  public void keyPressed() {
    if (key >= '1' && key <= '7') {
      currentPiece.undisplay();
      ghostPiece.undisplay();
      if (key == '1') currentPiece = new IPiece(0, 5, this);
      else if (key == '2') currentPiece = new OPiece (0, 4, this);
      else if (key == '3') currentPiece = new LPiece (1, 4, this);
      else if (key == '4') currentPiece = new JPiece(1, 4, this);
      else if (key == '5') currentPiece = new ZPiece(1, 4, this);
      else if (key == '6') currentPiece = new SPiece(1, 4, this);
      else if (key == '7') currentPiece = new TPiece(1, 4, this);
      currentPiece.moveDown();
      currentPiece.moveDown();

      ghostPiece = newPiece(currentPiece.col);
      ghostPiece.col*=10;
    } else if (hasSaved == false && (key == 'c' || keyCode == SHIFT)) {
      currentPiece.undisplay();
      ghostPiece.undisplay();
      if (savedPiece == null) {
        savedPiece = newPiece(currentPiece.col);
        currentPiece = newPiece(nextPieces.get(nextPiece));
        ghostPiece = newPiece(currentPiece.col);
        ghostPiece.col*=10;
        nextPiece = (nextPiece + 1) % 14;
        int end = (nextPiece+3)%14;
        if (end == 0 || end == 7) Collections.shuffle(nextPieces.subList(end, end+7));
      } else {
        int savedCol = savedPiece.col;
        savedPiece = newPiece(currentPiece.col);
        currentPiece = newPiece(savedCol);
        ghostPiece = newPiece(currentPiece.col);
        ghostPiece.col*=10;
      }
      hasSaved = true;
      currentPiece.moveDown();
      currentPiece.moveDown();
    } else if (key == '0') {
      level++;
      if (level == 2) speed = .72f;
      else if (level == 3) speed = .63f;
      else if (level == 4) speed = .55f;
      else if (level == 5) speed = .47f;
      else if (level == 6) speed = .38f;
      else if (level == 7) speed = .3f;
      else if (level == 8) speed = .22f;
      else if (level == 9) speed = .13f;
      else if (level == 10) speed = .1f;
      else if (level == 11) speed = .08f;
      else if (level == 14) speed = .07f;
      else if (level == 17) speed = .05f;
      else if (level == 20) speed = .03f;
      else if (level == 30) speed = .02f;
    }
  }

  public void display(int m, int s) {
    if (m >= s) {
      clearLine();
      playPiece();
      //show2D(grid);
    }
    //System.out.println("r: " + currentPiece.r + " c: "+ currentPiece.c + " cords: " + Arrays.toString(currentPiece.cords));
    currentPiece.undisplay();
    ghostPiece.undisplay();
    System.arraycopy(currentPiece.cords, 0, ghostPiece.cords, 0, currentPiece.cords.length);
    ghostPiece.r = currentPiece.r;
    ghostPiece.c = currentPiece.c;
    ghostPiece.orientation = currentPiece.orientation;
    //System.out.println("r: " + ghostPiece.r + " c: "+ ghostPiece.c + " cords: " + Arrays.toString(ghostPiece.cords));
    while (!ghostPiece.isColliding()) {
      ghostPiece.moveDown();
    }
    ghostPiece.display();
    currentPiece.display();
    pushMatrix();
    translate(140, 20);
    showBoard();
    popMatrix();
  }
}
class IPiece extends Piece {

  /*
   orientation = 0 --> on its side - center is third from the left
   orientation = 1 --> upright - center is third from the top
   orientation = 2 --> on its side - center is second from the left
   orientation = 3 --> upright - center is second from the top
   */

  IPiece(int r, int c, Board b) { 
    super(r, c, b);
    cords = new int[]{r, c-2, r, c-1, r, c+1};
    col = 2;
  }

  public void rot() {
    if (orientation == 0) {
      if (r > 2 && checkCords(new int[]{r-1, c, r+1, c, r+2, c})) {
        undisplay();
        r+=1; //0 -> 1
        cords = new int[]{r-2, c, r-1, c, r+1, c};
        display();
        orientation = 1;
      }
    } else if (orientation == 1) {
      if (!checkLeft()) {
        if (checkCords(new int[]{r, c+1, r, c+2, r, c+3})) {
          undisplay();
          c+=1;
          cords = new int[]{r, c-1, r, c+1, r, c+2};
          display();
          orientation = 2;
        }
      } else if (!checkRight()) {
        if (checkCords(new int[]{r, c-1, r, c-2, r, c-3})) {
          undisplay();
          c-=2;
          cords = new int[]{r, c-1, r, c+1, r, c+2};
          display();
          orientation = 2;
        }
      } else if (checkCords(new int[]{r, c-2, r, c-1, r, c+1})) {
        undisplay();
        c-=1; //1 -> 2
        cords = new int[]{r, c-1, r, c+1, r, c+2};
        display();
        orientation = 2;
      } else if (c == 1) {
        if (checkCords(new int[]{r, c-1, r, c+1, r, c+1})) {
          undisplay();
          cords = new int[]{r, c-1, r, c+1, r, c+2};
          display();
          orientation = 2;
        }
      }
    } else if (orientation == 2) {
      if (checkCords(new int[]{r-2, c, r-1, c, r+1, c})) {
        undisplay();
        r-=1; //2 -> 3
        cords = new int[]{r-1, c, r+1, c, r+2, c};
        display();
        orientation = 3;
      }
    } else { //orientation == 3
      if (!checkLeft()) {
        if (checkCords(new int[]{r, c+1, r, c+2, r, c+3})) {
          undisplay();
          c+=2;
          cords = new int[]{r, c-2, r, c-1, r, c+1};
          display();
          orientation = 0;
        }
      } else if (!checkRight()) {
        if (checkCords(new int[]{r, c-3, r, c-2, r, c-1})) {
          undisplay();
          c-=1;
          cords = new int[]{r, c-2, r, c-1, r, c+1};
          display();
          orientation = 0;
        }
      } else if (!checkCords(new int[]{r,c+2})) {
        if (checkCords(new int[]{r, c-3, r, c-2, r, c-1})) {
          undisplay();
          cords = new int[]{r, c-2, r, c-1, r, c+1};
          display();
          orientation = 0;
        }
      } else if (checkCords(new int[]{r, c-1, r, c+1, r, c+2})) {
        undisplay();
        c+=1; //3 -> 0
        cords = new int[]{r, c-2, r, c-1, r, c+1};
        display();
        orientation = 0;
      }
    }
  }

  public boolean isColliding() {
    if (orientation == 0) return !checkCords(new int[]{r+1, c-2, r+1, c-1, r+1, c, r+1, c+1});
    if (orientation == 1) return !checkCords(new int[]{r+2, c});
    if (orientation == 2) return !checkCords(new int[]{r+1, c-1, r+1, c, r+1, c+1, r+1, c+2});
    //orientation == 3
    return !checkCords(new int[]{r+3, c});
  }

  public boolean checkLeft() {
    if (orientation == 0) return checkCords(new int[]{r, c-3});
    if (orientation == 1) return checkCords(new int[]{r-2, c-1, r-1, c-1, r, c-1, r+1, c-1});
    if (orientation == 2) return checkCords(new int[]{r, c-2});
    //orientation == 3 
    return checkCords(new int[]{r-1, c-1, r, c-1, r+1, c-1, r+2, c-1});
  }

  public boolean checkRight() {
    if (orientation == 0) return checkCords(new int[]{r, c+2});
    if (orientation == 1) return checkCords(new int[]{r-2, c+1, r-2, c+1, r, c+1, r+1, c+1});
    if (orientation == 2) return checkCords(new int[]{r, c+3});
    //orientation == 3 
    return checkCords(new int[]{r-1, c+1, r, c+1, r+1, c+1, r+2, c+1});
  }
}
class JPiece extends Piece {

  /*
  center is second from the top of the "J"
   orientation = 0 --> on its side - long side on the bottom
   orientation = 1 --> upright - upside down J
   orientation = 2 --> on its side - short side on bottom
   orientation = 3 --> upright - regular J
   */

  JPiece(int r, int c, Board b) {
    super(r, c, b);
    cords = new int[]{r-1, c-1, r, c-1, r, c+1};
    col = 4;
  }

  public void rot() {
    if (orientation == 0) {
      if (checkCords(new int[]{r-1,c,r-1,c+1,r+1,c})) {
        undisplay();
        cords = new int[]{r-1,c,r-1,c+1,r+1,c};
        display();
        orientation = 1;
      }
    } else if (orientation == 1) {
      if(!checkLeft() && checkCords(new int[]{r,c+1,r,c+2,r+1,c+2})){
        undisplay();
        c++;
        cords = new int[]{r,c-1,r,c+1,r+1,c+1};
        display();
        orientation = 2;
      }
      else if (checkCords(new int[]{r,c-1,r,c+1,r+1,c+1})) {
        undisplay();
        cords = new int[]{r,c-1,r,c+1,r+1,c+1};
        display();
        orientation = 2;
      }
    } else if (orientation == 2) {
      if (checkCords(new int[]{r+1,c-1,r+1,c,r-1,c})) {
        undisplay();
        cords = new int[]{r+1,c-1,r+1,c,r-1,c};
        display();
        orientation = 3;
      }
    } else { //orientation == 3
      if(!checkRight() && checkCords(new int[]{r,c-1,r,c-2,r-1,c-2})){
        undisplay();
        c--;
        cords = new int[]{r-1,c-1,r,c-1,r,c+1};
        display();
        orientation = 0;
      }
      else if (checkCords(new int[]{r-1,c-1,r,c-1,r,c+1})) {
        undisplay();
        cords = new int[]{r-1,c-1,r,c-1,r,c+1};
        display();
        orientation = 0;
      }
    }
  }

  public boolean isColliding() {
    if (orientation == 0) return !checkCords(new int[]{r+1,c-1,r+1,c,r+1,c+1});
    if (orientation == 1) return !checkCords(new int[]{r+2,c,r,c+1});
    if (orientation == 2) return !checkCords(new int[]{r+1,c-1,r+1,c,r+2,c+1});
    //orientation == 3
    return !checkCords(new int[]{r+2,c-1,r+2,c});
  }

  public boolean checkLeft() {
    if(orientation == 0) return checkCords(new int[]{r-1,c-2,r,c-2});
    if(orientation == 1) return checkCords(new int[]{r-1,c-1,r,c-1,r+1,c-1});
    if(orientation == 2) return checkCords(new int[]{r,c-2,r+1,c});
    //orientation = 3
    return checkCords(new int[]{r-1,c-1,r,c-1,r+1,c-2});
  }

  public boolean checkRight() {
    if(orientation == 0) return checkCords(new int[]{r-1,c,r,c+2});
    if(orientation == 1) return checkCords(new int[]{r-1,c+2,r,c+1,r+1,c+1});
    if(orientation == 2) return checkCords(new int[]{r,c+2,r+1,c+2});
    //orientation = 3
    return checkCords(new int[]{r-1,c+1,r,c+1,r+1,c+1});
  }
  
}
class LPiece extends Piece {

  /*
  center is second from the top of the "L"
   orientation = 0 --> on its side - long side on the bottom
   orientation = 1 --> upright - regular L
   orientation = 2 --> on its side - short side on bottom
   orientation = 3 --> upright - upsidedown L
   */

  LPiece(int r, int c, Board b) {
    super(r, c, b);
    cords = new int[]{r, c-1, r, c+1, r-1, c+1};
    col = 3;
  }

  public void rot() {
    if (orientation == 0) {
      if (checkCords(new int[]{r-1,c,r+1,c,r+1,c+1})){
        undisplay();
        cords = new int[]{r-1,c,r+1,c,r+1,c+1};
        display();
        orientation = 1;
      }
    } else if (orientation == 1) {
      if(!checkLeft() && checkCords(new int[]{r,c+1,r,c+2})){
        undisplay();
        c++;
        cords = new int[]{r+1,c-1,r,c-1,r,c+1};
        display();
        orientation = 2;
      }
      else if (checkCords(new int[]{r+1,c-1,r,c-1,r,c+1})){
        undisplay();
        cords = new int[]{r+1,c-1,r,c-1,r,c+1};
        display();
        orientation = 2;
      }
    } else if (orientation == 2) {
      if (checkCords(new int[]{r-1,c-1,r-1,c,r+1,c})){
        undisplay();
        cords = new int[]{r-1,c-1,r-1,c,r+1,c};
        display();
        orientation = 3;
      }
    } else { //orientation == 3
      if(!checkRight() && checkCords(new int[]{r,c-1,r,c-2})){
        undisplay();
        c--;
        cords = new int[]{r,c-1,r,c+1,r-1,c+1};
        display();
        orientation = 0;
      }
      else if (checkCords(new int[]{r,c-1,r,c+1,r-1,c+1})){
        undisplay();
        cords = new int[]{r,c-1,r,c+1,r-1,c+1};
        display();
        orientation = 0;
      }
    }
  }

  public boolean isColliding() {
    if (orientation == 0) return !checkCords(new int[]{r+1,c-1,r+1,c,r+1,c+1});
    if (orientation == 1) return !checkCords(new int[]{r+2,c,r+2,c+1});
    if (orientation == 2) return !checkCords(new int[]{r+2,c-1,r+1,c,r+1,c+1});
    //orientation == 3
    return !checkCords(new int[]{r,c-1,r+2,c});
  }

  public boolean checkLeft() {
    if(orientation == 0) return checkCords(new int[]{r,c-2,r-1,c});
    if(orientation == 1) return checkCords(new int[]{r-1,c-1,r,c-1,r+1,c-1});
    if(orientation == 2) return checkCords(new int[]{r,c-2,r+1,c-2});
    //orientation = 3
    return checkCords(new int[]{r-1,c-2,r,c-1,r+1,c-1});
  }

  public boolean checkRight() {
    if(orientation == 0){
      return !(c >= b.grid[0].length-2 || b.grid[r][c+2] != 0 || b.grid[r-1][c+2] != 0);
    }
    if(orientation == 1){
      return !(c >= b.grid[0].length-2 || b.grid[r-1][c+1] != 0 || b.grid[r][c+1] != 0 || b.grid[r+1][c+2] != 0);
    }
    if(orientation == 2){
      return !(c >= b.grid[0].length-2 || b.grid[r][c+2] != 0 || b.grid[r+1][c] != 0);
    }
    //orientation = 3
    return !(c >= b.grid[0].length-1 || b.grid[r-1][c+1] != 0 || b.grid[r][c+1] != 0 || b.grid [r+1][c+1] !=0);
  }
}
class OPiece extends Piece {

  OPiece(int r, int c, Board b) { //center is the top left tile
    super(r, c, b);
    cords = new int[]{r, c+1, r+1, c, r+1, c+1};
    col = 1;
  }

  public boolean isColliding() { //return if the spaces under are empty
    return !checkCords(new int[]{r+2,c,r+2,c+1});
  }

  public void rot() {
  }

  public boolean checkLeft(){
    return checkCords(new int[]{r,c-1,r+1,c-1});
  }

  public boolean checkRight(){
    return checkCords(new int[]{r,c+2,r+1,c+2});
  }
}
abstract class Piece {
  int r;
  int c;
  int orientation, col;
  Board b;
  int[] cords;

  Piece(int r, int c, Board b) {  
    this.r = r;
    this.c = c;
    this.b = b;
    orientation = 0;
  }
  
  public boolean checkCords(int[] cords){
    for(int i = 0; i < cords.length; i+= 2){
      int tempr = cords[i];
      int tempc = cords[i+1];
      if(tempr < 1 || tempc < 0 || tempc > b.grid[0].length-1 || (b.grid[tempr][tempc] != 0 && b.grid[tempr][tempc] != col*10)) return false;
    }
    return true;
  }

  public void moveLeft() {
    undisplay();
    c -= 1;
    for (int i = 1; i<cords.length; i+=2) {
      cords[i]--;
    }
    display();
  }
  public void moveRight() {
    undisplay();
    c += 1;
    for (int i = 1; i<cords.length; i+=2) {
      cords[i]++;
    }
    display();
  }
  public void moveDown() {
    if (!isColliding()) {
      undisplay();
      r += 1;
      for (int i = 0; i<cords.length; i+=2) {
        cords[i]++;
      }
      display();
    }
  }

  public String toString() {
    return "Piece";
  }

  public void keyPressed() {
    if (keyCode == LEFT && checkLeft()) moveLeft();
    else if (keyCode == RIGHT && checkRight()) {
      moveRight();
    } else if (keyCode == UP) {
      rot();
    } else if (key == ' ') {
      while (!isColliding()) {
        moveDown();
      }
      b.clearLine();
      b.playPiece();
    } else if (keyCode == DOWN) {
      moveDown();
    }
  }

  public abstract boolean checkLeft();
  public abstract boolean checkRight();
  public abstract boolean isColliding();
  public abstract void rot();

  public void display() {
    for (int i = 0; i < cords.length; i += 2) {
      //System.out.println("r: "+cords[i] + " c: " + cords[i+1]);
      b.grid[cords[i]][cords[i+1]] = col;
    }
    b.grid[r][c] = col;
  }

  public void undisplay() {
    for (int i = 0; i < cords.length; i += 2) {
      b.grid[cords[i]][cords[i+1]] = 0;
    }
    b.grid[r][c] = 0;
  }
}
class SPiece extends Piece {
  /*
  orientation = 0 --> regular S shape center is the bottom right piece in the "s"
   orientation = 1 --> vertical S center is the middle left piece
   orientation = 2 --> regular S center is the top left
   orientation = 3 --> vertical s center is the middle right piece
   */

  SPiece(int r, int c, Board b) {
    super(r, c, b);
    cords = new int[]{r, c-1, r-1, c, r-1, c+1};
    col = 5;
  }

  public void rot() {
    if (orientation == 0) {
      if (checkCords(new int[]{r, c+1, r+1, c+1})) {
        undisplay();
        cords = new int[]{r-1, c, r, c+1, r+1, c+1};
        display();
        orientation = (orientation + 1)%4;
      }
    } else if (orientation == 1) {
      if (!checkLeft() && checkCords(new int[]{r, c+2, r+1, c })) {
        undisplay();
        c++;
        cords = new int[]{r+1, c-1, r+1, c, r, c+1};
        display();
        orientation = (orientation + 1)%4;
      } else if (checkCords(new int[]{r+1, c-1, r+1, c})) {
        undisplay();
        cords = new int[]{r+1, c-1, r+1, c, r, c+1};
        display();
        orientation = (orientation + 1)%4;
      }
    } else if (orientation == 2) {
      if (checkCords(new int[]{r-1, c-1, r, c-1})) {
        undisplay();
        cords = new int[]{r-1, c-1, r, c-1, r+1, c};
        display();
        orientation = (orientation + 1)%4;
      }
    } else { //orientation == 3
      if (!checkRight() && checkCords(new int[]{r, c-2, r-1, c})) {
        undisplay();
        c--;
        cords = new int[]{r, c-1, r-1, c, r-1, c+1};
        display();
        orientation = (orientation + 1)%4;
      } else if (checkCords(new int []{r-1, c, r-1, c+1})) {
        undisplay();
        cords = new int[]{r, c-1, r-1, c, r-1, c+1};
        display();
        orientation = (orientation + 1)%4;
      }
    }
  }

  public boolean isColliding() {
    if (orientation == 0) {
      return !checkCords(new int[]{r+1, c-1, r+1, c, r, c+1});
    }
    if (orientation == 1) {
      return !checkCords(new int[]{r+1, c, r+2, c+1});
    }
    if (orientation == 2) {
      return !checkCords(new int[]{r+2, c-1, r+2, c, r+1, c+1});
    }
    //orientation == 3
    return !checkCords(new int[]{r+1, c-1, r+2, c});
  }

  public boolean checkLeft() {
    if (orientation == 0) return checkCords(new int[]{r, c-2, r-1, c-1});
    if (orientation == 1) return checkCords(new int[]{r, c-1, r-1, c-1, r+1, c});
    if (orientation == 2) return checkCords(new int[]{r, c-1, r+1, c-2});
    if (orientation == 3) return checkCords(new int[]{r, c-2, r-1, c-2, r+1, c-1});
    return true;
  }

  public boolean checkRight() {
    if (orientation == 0) return checkCords(new int[]{r, c+1, r-1, c+2});
    if (orientation == 1) return checkCords(new int[]{r, c+2, r-1, c+1, r+1, c+2});
    if (orientation == 2) return checkCords(new int[]{r, c+2, r+1, c+1});
    if (orientation == 3) return checkCords(new int[]{r, c+1, r-1, c, r+1, c+1});
    return true;
  }
}
class TPiece extends Piece {
  /* reference to the piece sticking out
   orientation = 0 --> up
   orientation = 1 --> right
   orientation = 2 --> down
   orientation = 3 --> left
   */

  TPiece(int r, int c, Board b) {
    super(r, c, b);
    cords = new int[]{r, c-1, r-1, c, r, c+1};
    col = 7;
  }

  public void rot() {
    if (orientation == 0) {
      if (checkCords(new int[]{r+1, c})) {
        undisplay();
        cords = new int[]{r-1, c, r, c+1, r+1, c};
        display();
        orientation = 1;
      }
    } else if (orientation == 1) {
      if (!checkLeft() && checkCords(new int[]{r+1, c+1, r, c+2})) {
        undisplay();
        c++;
        cords = new int[]{r, c-1, r+1, c, r, c+1};
        display();
        orientation = 2;
      } else if (checkCords(new int[]{r, c-1})) {
        undisplay();
        cords = new int[]{r, c-1, r, c+1, r+1, c};
        display();
        orientation = 2;
      }
    } else if (orientation == 2) {
      if (checkCords(new int[]{r-1, c})) {
        undisplay();
        cords = new int[]{r-1, c, r, c-1, r+1, c};
        display();
        orientation = 3;
      }
    } else { //orientation == 3
      if (!checkRight() && checkCords(new int[]{r, c-2, r+1, c-1})) {
        undisplay();
        c--;
        cords = new int[]{r, c-1, r, c+1, r-1, c};
        display();
        orientation = 0;
      } else if (checkCords(new int[]{r, c+1})) {
        undisplay();
        cords = new int[]{r, c-1, r-1, c, r, c+1};
        display();
        orientation = 0;
      }
    }
  }

  public boolean isColliding() {
    if (orientation == 0) return !checkCords(new int[]{r+1, c-1, r+1, c, r+1, c+1});
    if (orientation == 1) return !checkCords(new int[]{r+2, c, r+1, c+1});
    if (orientation == 2) return !checkCords(new int[]{r+1, c-1, r+2, c, r+1, c+1});
    //orientation == 3
    return !checkCords(new int[]{r+1, c-1, r+2, c});
  }

  public boolean checkLeft() {
    if (orientation == 0) return checkCords(new int[]{r-1, c-1, r, c-2});
    if (orientation == 1) return checkCords(new int[]{r-1, c-1, r, c-1, r+1, c-1});
    if (orientation == 2) return checkCords(new int[]{r, c-2, r+1, c-1});
    //orientation == 3
    return checkCords(new int[]{r-1, c-1, r, c-2, r+1, c-1});
  }

  public boolean checkRight() {
    if (orientation == 0) return checkCords(new int[]{r-1, c+1, r, c+2});
    if (orientation == 1) return checkCords(new int[]{r-1, c+1, r, c+2, r+1, c+1});
    if (orientation == 2) return checkCords(new int[]{r, c+2, r+1, c+1});
    //orientation == 3
    return checkCords(new int[]{r-1, c+1, r, c+1, r+1, c+1});
  }
}
class ZPiece extends Piece {
  /*
  orientation = 0 --> regular S shape center is the bottom right piece in the "s"
   orientation = 1 --> vertical S center is the middle left piece
   orientation = 2 --> regular S center is the top left
   orientation = 3 --> certical s center is the middle right piece
   */

  ZPiece(int r, int c, Board b) {
    super(r, c, b);
    cords = new int[]{r-1, c-1, r-1, c, r, c+1};
    col = 6;
  }

  public void rot() {
    if (orientation == 0) {
      if (checkCords(new int[]{r-1,c+1,r+1,c})){
        undisplay();
        cords = new int[]{r-1, c+1, r, c+1, r+1, c};
        display();
        orientation = 1;
      }
    } else if (orientation == 1) {
      if(!checkLeft() && checkCords(new int[]{r+1,c+1,r+1,c+2})){
        undisplay();
        c++;
        cords = new int[]{r, c-1, r+1, c, r+1, c+1};
        display();
        orientation = 2;
      }
      else if (checkCords(new int[]{r,c-1,r+1,c+1})){
        undisplay();
        cords = new int[]{r, c-1, r+1, c, r+1, c+1};
        display();
        orientation = 2;
      }
    } else if (orientation == 2) {
      if (checkCords(new int[]{r-1,c,r+1,c-1})) {
        undisplay();
        cords = new int[]{r+1, c-1, r, c-1, r-1, c};
        display();
        orientation = 3;
      }
    } else { //orientation == 3
      if(!checkRight() && checkCords(new int[]{r-1,c-2,r-1,c-1})){
        undisplay();
        c--;
        cords = new int[]{r-1, c-1, r-1, c, r, c+1};
        display();
        orientation = 0;
      }
      else if (checkCords(new int[]{r-1,c-1,r,c+1})){
        undisplay();
        cords = new int[]{r-1, c-1, r-1, c, r, c+1};
        display();
        orientation = 0;
      }
    }
  }

  public boolean isColliding() {
    if (orientation == 0) return !checkCords(new int[]{r,c-1,r+1,c,r+1,c+1});
    if (orientation == 1) return !checkCords(new int[]{r+2,c,r+1,c+1});
    if (orientation == 2) return !checkCords(new int[]{r+1,c-1,r+2,c,r+2,c+1});
    //orientation == 3
    return !checkCords(new int[]{r+2,c-1,r+1,c});
  }

  public boolean checkLeft() {
    if (orientation == 0) return checkCords(new int[]{r-1,c-2,r,c-1});
    if (orientation == 1) return checkCords(new int[]{r-1,c,r,c-1,r+1,c-1});
    if (orientation == 2) return checkCords(new int[]{r,c-2,r+1,c-1});
    //orientation == 3
    return checkCords(new int[]{r-1,c-1,r,c-2,r+1,c-2});
  }

  public boolean checkRight() {
    if (orientation == 0) return checkCords(new int[]{r-1,c+1,r,c+2});
    if (orientation == 1) return checkCords(new int[]{r-1,c+2,r,c+2,r+1,c+1});
    if (orientation == 2) return checkCords(new int[]{r,c+1,r+1,c+2});
    //orientation == 3
    return checkCords(new int[]{r-1,c+1,r,c+1,r+1,c});
  }
}
  public void settings() {  size(900, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Tetris" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
